AutoZeff: Effective Atomic Number Calculation Software.

---------------------------------------
System Requirements
---------------------------------------
The AutoZeff software requires Windows XP service pack 3 as a minimal operating system. More recent versions of Windows OS is desired. AutoZeff uses version 4.0 of the .NET framework. This must be installed on the computer before AutoZeff is used.

---------------------------------------
Installation
---------------------------------------

Extract the downloaded zip file and save the AutoZeff folder on your computer in the location of your choice.
To run the software, double click the AutoZeff.exe file.


---------------------------------------
ADHESION CONTRACT / DISCLAIMER
---------------------------------------
By using this software, the user agrees to cite the following article in any published scientific papers, reports (internal or otherwise), theses and so on:
ML Taylor, RL Smith, F Dossing and RD Franich, Robust calculation of effective atomic numbers: The Auto-Zeff software, Medical Physics 39 (2012) 1769-1778

This citation is available to copy/paste from the Citation menu within the software.

The user furthermore agrees not to reverse-engineer or otherwise modify the software in any way. The authors of the software hold no responsibility for any virus or otherwise adverse impact upon the users' systems.
This version of the software is executable on Windows (Microsoft Corporation, USA) systems only.

